import os
from PyQt5.QtCore import QFileSystemWatcher, QTimer
from queue import Queue

class FileWatcher:
    def __init__(self, plugin):
        self.plugin = plugin
        self.watcher = QFileSystemWatcher()
        self.watched_folders = set()
        self.watched_dirs = set()
        self.file_queue = Queue()
        self.scan_timer = QTimer()
        self.scan_timer.setSingleShot(True)
        self.scan_timer.setInterval(1000)  # 1 second delay
        self.scan_timer.timeout.connect(self._delayed_scan)
        self.watching = False
        self.is_scanning = False
        self.scanning = False
        self.current_folder = None
        self.active = False
        
        # Connect signals
        self.watcher.directoryChanged.connect(self.on_directory_changed)
        
        # Load previously watched folders
        self.reload_watched_folders()

    def start_watching(self):
        """Start watching folder"""
        self.active = True
        if self.current_folder:
            self.scan_folder(self.current_folder)

    def add_folder(self, folder_path):
        """Add folder to watch"""
        if not os.path.exists(folder_path):
            return False
            
        self.current_folder = folder_path
        self.watcher.addPath(folder_path)
        
        if self.active:
            self.scan_folder(folder_path)
        return True

    def scan_folder(self, root_folder):
        """Recursively scan for LAS files in all subdirectories"""
        try:
            all_las_files = {}  # Dictionary to group files by their directory
            
            # Walk through all subdirectories
            for root, dirs, files in os.walk(root_folder):
                # Add each subdirectory to watcher
                for dir_name in dirs:
                    dir_path = os.path.join(root, dir_name)
                    if dir_path not in self.watched_dirs:
                        self.watcher.addPath(dir_path)
                        self.watched_dirs.add(dir_path)
                
                # Find LAS files and group by folder
                las_files = [f for f in files if f.lower().endswith('.las')]
                if las_files:
                    # Use the actual folder path as the group identifier
                    folder_name = os.path.basename(root)
                    group_name = self._get_group_name(root, folder_name)
                    
                    if group_name not in all_las_files:
                        all_las_files[group_name] = []
                    
                    for file_name in las_files:
                        full_path = os.path.join(root, file_name)
                        
                        # Skip if already loaded in project
                        if self.plugin.is_layer_already_loaded(full_path):
                            continue
                        
                        all_las_files[group_name].append(full_path)
            
            # Sort and load files by group
            total_files = sum(len(files) for files in all_las_files.values())
            if total_files > 0:
                self.plugin.show_message("Info", 
                    f"Found {total_files} new LAS files in {len(all_las_files)} groups", 0, 3)
                
                # Process each group
                for group_name, file_paths in all_las_files.items():
                    file_paths.sort()  # Sort files within each group
                    for file_path in file_paths:
                        # Double check again before adding
                        if not self.plugin.is_layer_already_loaded(file_path):
                            self.plugin.layer_manager.add_layer_to_group(file_path, group_name)
                    
            else:
                self.plugin.show_message("Info", "No new LAS files found", 0, 2)
                    
        except Exception as e:
            self.plugin.show_error(f"Error scanning folders: {str(e)}")
    
    def _get_group_name(self, folder_path, folder_name):
        """Extract a meaningful group name from the folder"""
        # Use the relative path from the root folder
        if self.current_folder and folder_path.startswith(self.current_folder):
            # Create a relative path from the root watched folder
            rel_path = os.path.relpath(folder_path, self.current_folder)
            if rel_path == '.':  # If it's the root folder itself
                return folder_name
            return rel_path
        
        # Use direct parent folder name as fallback
        return folder_name

    def reload_watched_folders(self):
        """Reload all watched folders"""
        folders = self.plugin.settings.value("watcherfolder/folders", [], type=list)
        for folder in folders:
            if os.path.exists(folder):
                self.add_folder(folder)

    def on_directory_changed(self, path):
        """Handle directory changes"""
        # When a directory changes, scan it with a slight delay
        # to ensure file copying is complete
        QTimer.singleShot(2000, lambda: self.scan_folder(path))
        
    def _delayed_scan(self):
        """Scan after delay to ensure file is complete"""
        modified = False
        for folder in self.watched_folders:
            if os.path.exists(folder):
                if self.plugin.layer_manager.add_sequential_files(folder):
                    modified = True
                    
        if modified:
            self.plugin.save_project()

    def cleanup(self):
        """Cleanup watched directories"""
        if self.watcher:
            self.watcher.removePaths(list(self.watched_dirs))
        self.watched_dirs.clear()
