from PyQt5.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QDialogButtonBox, QMessageBox
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtCore import pyqtSignal
from qgis.core import QgsSettings
import os

class SettingsDialog(QDialog):
    folderChanged = pyqtSignal(str)  # Signal for folder changes

    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings = QgsSettings()
        self.setup_ui()
        self.load_settings()

    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Folder path input
        folder_layout = QHBoxLayout()
        self.folder_edit = QLineEdit()
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(self.browse_folder)
        folder_layout.addWidget(QLabel("Watch folder:"))
        folder_layout.addWidget(self.folder_edit)
        folder_layout.addWidget(browse_btn)
        
        layout.addLayout(folder_layout)
        
        # Buttons
        btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)
        
        self.setLayout(layout)
        self.setWindowTitle("LAS Folder Location")

    def browse_folder(self):
        """Browse for folder with validation"""
        last_location = self.settings.value("watcherfolder/last_browse_location", "")
        
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select LAS Folder",
            last_location,
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks
        )
        if folder and os.path.exists(folder):  # Verify folder exists
            self.settings.setValue("watcherfolder/last_browse_location", os.path.dirname(folder))
            self.folder_edit.setText(folder)
            self.folder_edit.setToolTip(folder)  # Add tooltip for long paths

    def load_settings(self):
        # Load folder path
        folder = self.settings.value("watcherfolder/last_folder", "")
        # If no last folder, try to use last browse location
        if not folder:
            folder = self.settings.value("watcherfolder/last_browse_location", "")
        self.folder_edit.setText(folder)

    def accept(self):
        """Handle dialog acceptance and folder change"""
        new_folder = self.folder_edit.text()
        if os.path.exists(new_folder):
            old_folder = self.settings.value("watcherfolder/last_folder", "")
            # Always emit change to ensure watcher updates
            self.settings.setValue("watcherfolder/last_folder", new_folder)
            self.settings.setValue("watcherfolder/loaded_files", [])
            self.folderChanged.emit(new_folder)
            super().accept()
        else:
            QMessageBox.warning(self, "Invalid Folder", "Please select a valid folder path.")
