import os
from qgis.core import QgsProject, QgsSettings, QgsPointCloudLayer
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QAction, QFileDialog
from .settings_dialog import SettingsDialog
from .layer_manager import LayerManager
from .file_watcher import FileWatcher

class FileSystemWatcherPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.settings = QgsSettings()
        self.settings_action = None
        self.folder_action = None
        
        # Initialize components
        self.layer_manager = LayerManager(self)
        self.file_watcher = FileWatcher(self)
        
        # Load settings and start
        self.load_settings()
        self.qgis_ready = False
        # Wait for QGIS to fully load (15 seconds)
        QTimer.singleShot(15000, self.check_qgis_ready)
        
        self.all_files_loaded = False

    def check_qgis_ready(self):
        """Check if QGIS is fully loaded"""
        try:
            canvas = self.iface.mapCanvas()
            project = QgsProject.instance()
            if canvas and project and not canvas.isFrozen():
                self.qgis_ready = True
                self.show_message("Info", "Watcher plugin ready to use", 0, 3)
                self.start_loading_sequence()
            else:
                # Check again in 5 seconds
                QTimer.singleShot(5000, self.check_qgis_ready)
        except Exception as e:
            # If any error, retry in 5 seconds
            QTimer.singleShot(5000, self.check_qgis_ready)

    def start_loading_sequence(self):
        """Handle sequential loading"""
        # Only start watcher, wait for user input for folder selection
        QTimer.singleShot(1000, self.file_watcher.start_watching)

    def initGui(self):
        """Create the menu entries and toolbar icons"""
        # Settings button
        self.settings_action = QAction("Watcher Settings", self.iface.mainWindow())
        self.settings_action.triggered.connect(self.show_settings)
        self.iface.addToolBarIcon(self.settings_action)
        
        # Add folder button
        self.folder_action = QAction("Add Watch Folder", self.iface.mainWindow())
        self.folder_action.triggered.connect(self.add_watch_folder)
        self.iface.addToolBarIcon(self.folder_action)

    def add_watch_folder(self, folder=None):
        """Show folder selection dialog or use provided folder"""
        if not self.qgis_ready:
            self.show_message("Warning", "Please wait for QGIS to finish loading...", 1, 3)
            return

        if folder is None:
            folder = QFileDialog.getExistingDirectory(
                self.iface.mainWindow(),
                "Select Folder to Watch",
                ""  # Start from empty/default location
            )
        if folder:
            self.show_message("Info", "Adding folder, please wait...", 0, 3)
            QTimer.singleShot(1000, lambda: self._delayed_add_folder(folder))

    def _delayed_add_folder(self, folder):
        """Add folder after delay"""
        if self.file_watcher:
            self.file_watcher.cleanup()
        self.settings.setValue("watcherfolder/last_folder", folder)
        self.file_watcher.add_folder(folder)
        self.show_success(f"Now watching: {folder}")

    def show_message(self, title, message, level, duration):
        """Show message in QGIS message bar"""
        self.iface.messageBar().pushMessage(title, message, level, duration)

    def show_error(self, message):
        """Show error message"""
        self.show_message("Error", message, 2, 5)

    def show_success(self, message):
        """Show success message"""
        self.show_message("Success", message, 0, 3)

    def load_settings(self):
        """Load saved settings"""
        if not self.settings.value("watcherfolder/last_folder"):
            self.settings.setValue("watcherfolder/last_folder", "")

    def get_project_name(self):
        """Get project name based on first LAS file pattern"""
        layers = QgsProject.instance().mapLayers().values()
        
        # Sort layers by name to ensure consistent order
        sorted_layers = sorted([l for l in layers if isinstance(l, QgsPointCloudLayer)], 
                             key=lambda x: x.name())
        
        if sorted_layers:
            file_name = os.path.basename(sorted_layers[0].source())
            parts = file_name.split('_')
            
            # Handle expected naming pattern L1_1_UG_B_refl_001
            if len(parts) >= 4:
                try:
                    # Look for UG_B pattern
                    ug_index = next(i for i, part in enumerate(parts) if part.upper() == 'UG')
                    sequence = parts[ug_index-1]  # Get sequence number
                    section = parts[ug_index+1]   # Get section letter
                    return f"{sequence}_UG_{section}"
                except:
                    return parts[0]  # Fallback to first part
                    
        return "watcher_project"

    def save_project(self):
        """Save QGIS project with smart naming"""
        if not self.settings.value("watcherfolder/last_folder") or not self.all_files_loaded:
            return
            
        project_name = self.get_project_name()
        project_path = os.path.join(
            self.settings.value("watcherfolder/last_folder"),
            f"{project_name}.qgs"
        )
        
        QgsProject.instance().write(project_path)
        self.settings.setValue("watcherfolder/last_project", project_path)
        self.show_success(f"Project saved as: {project_name}.qgs")

    def load_last_project(self):
        """Load last saved project if exists"""
        project_path = self.settings.value("watcherfolder/last_project")
        if project_path and os.path.exists(project_path):
            self.show_message("Info", f"Loading project: {project_path}", 0, 3)
            if QgsProject.instance().read(project_path):
                self.show_success("Previous project loaded")
            else:
                self.show_error("Failed to load previous project")

    def restore_previous_layers(self):
        """Restore previously loaded layers"""
        loaded_files = self.settings.value("watcherfolder/loaded_files", [], type=list)
        if not loaded_files:
            return
            
        self.show_message("Info", f"Restoring {len(loaded_files)} LAS files...", 0, 3)
        loaded_count = 0
        
        for file_path in loaded_files:
            if os.path.exists(file_path):
                if self.layer_manager.add_layer(file_path):
                    loaded_count += 1
                    
        self.show_message("Success", f"Restored {loaded_count} LAS files", 0, 3)
        
        if loaded_count > 0:
            self.show_success("All layers loaded successfully")
        else:
            self.show_message("Info", "No layers to restore", 0, 3)

    def show_settings(self):
        """Show the settings dialog"""
        dialog = SettingsDialog(self.iface.mainWindow())
        dialog.folderChanged.connect(self.add_watch_folder)
        if dialog.exec_():
            self.file_watcher.reload_watched_folders()

    def on_folder_changed(self, new_folder):
        """Handle folder change from settings"""
        if self.file_watcher:
            self.file_watcher.cleanup()  # Clear old watched folders
        self.show_message("Info", f"Changed watch folder to: {new_folder}", 0, 3)
        QTimer.singleShot(1000, lambda: self.file_watcher.add_folder(new_folder))

    def unload(self):
        """Cleanup when plugin is unloaded"""
        if self.layer_manager:
            self.layer_manager.cleanup()
            
        if self.file_watcher:
            self.file_watcher.cleanup()
            
        # Remove UI elements
        if self.settings_action:
            self.iface.removeToolBarIcon(self.settings_action)
            self.iface.removePluginMenu("Watcher Folder", self.settings_action)
            self.settings_action = None
            
        if self.folder_action:
            self.iface.removeToolBarIcon(self.folder_action)
            self.iface.removePluginMenu("Watcher Folder", self.folder_action)
            self.folder_action = None

def classFactory(iface):
    """Load the plugin class."""
    return FileSystemWatcherPlugin(iface)