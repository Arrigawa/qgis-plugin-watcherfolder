import os
from qgis.core import QgsProject, QgsVectorLayer, QgsRasterLayer, QgsPointCloudLayer, QgsLayerTreeGroup, QgsMapLayer
from PyQt5.QtCore import Qt, QEventLoop, QTimer
import time

class LayerManager:
    def __init__(self, plugin):
        self.plugin = plugin
        self.iface = plugin.iface
        self.root = QgsProject.instance().layerTreeRoot()
        self.groups = {}
        self.processed_files = set()  # Track processed files
        self.rendered_files = set()  # Track successfully rendered files
        self.last_group = None
        self.processed_paths = {}  # Track processed files by full path
        self.layer_names = set()   # Track layer names
        self.loaded_sources = set()  # Track loaded file paths
        self.pending_renders = 0
        self.pending_files = []
        self.is_loading = False
        self.current_file = None  # Track current file being processed
        self.processing = False   # Processing state flag
        self.file_queue = []
        self.failed_files = []
        self.retry_counts = {}
        self.loading = False
        self.max_retries = 3
        self.pending_layers = []
        self.current_layer = None
        self.loaded_files = set()  # Track loaded file paths
        self.loaded_paths = set()
        self.folder_groups = {}  # Track groups by folder

    def is_layer_loaded(self, file_path):
        """Check if layer is already loaded"""
        # Check our tracking set
        if file_path in self.loaded_sources:
            return True
            
        # Check existing layers in project
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsPointCloudLayer):
                if layer.source() == file_path:
                    self.loaded_sources.add(file_path)
                    return True
        return False

    def is_duplicate(self, file_path):
        """Check if a file is already loaded as a layer"""
        # Normalize paths for comparison
        normalized_path = os.path.normpath(file_path)
        
        # Check in various tracking sets
        if normalized_path in self.loaded_paths:
            return True
        
        # Check loaded sources directly
        if normalized_path in self.loaded_sources:
            return True
            
        # Also check directly in the project
        for layer_id, layer in QgsProject.instance().mapLayers().items():
            if isinstance(layer, QgsPointCloudLayer):
                layer_source = os.path.normpath(layer.source())
                if layer_source == normalized_path:
                    # Found a match - add to our tracking for future
                    self.loaded_paths.add(normalized_path)
                    self.loaded_sources.add(normalized_path)
                    return True
        
        return False

    def save_loaded_file(self, file_path):
        """Save loaded file to settings"""
        loaded_files = self.plugin.settings.value("watcherfolder/loaded_files", [], type=list)
        if file_path not in loaded_files:
            loaded_files.append(file_path)
            self.plugin.settings.setValue("watcherfolder/loaded_files", loaded_files)

    def _get_folder_group_name(self, file_path):
        """Get group name from first LAS file in folder"""
        folder = os.path.dirname(file_path)
        if folder not in self.folder_groups:
            try:
                # Find first LAS file in folder
                las_files = sorted([f for f in os.listdir(folder) if f.lower().endswith('.las')])
                if las_files:
                    first_file = las_files[0]
                    parts = first_file.split('_')
                    if len(parts) >= 4:
                        # Look for UG_X pattern
                        for i in range(len(parts)-1):
                            if parts[i].upper() == 'UG':
                                group_name = f"{parts[i-1]}_{parts[i]}_{parts[i+1]}"
                                self.folder_groups[folder] = group_name
                                return group_name
                    # Fallback to first part
                    self.folder_groups[folder] = parts[0]
                    return parts[0]
            except:
                pass
            # Default fallback
            base_name = os.path.basename(folder)
            self.folder_groups[folder] = base_name
            return base_name
        return self.folder_groups[folder]

    def add_layer(self, file_path):
        """Add layer with smart grouping"""
        if file_path in self.loaded_paths:
            return True
            
        try:
            layer = QgsPointCloudLayer(file_path, os.path.basename(file_path), "pdal")
            if layer and layer.isValid():
                # Get or create folder group
                folder_group_name = self._get_folder_group_name(file_path)
                folder_group = self._get_or_create_group(folder_group_name)
                
                # Add layer to project and group
                QgsProject.instance().addMapLayer(layer, False)
                folder_group.addLayer(layer)
                
                self.loaded_paths.add(file_path)
                self.plugin.show_success(f"Added to {folder_group_name}: {os.path.basename(file_path)}")
                return True
        except Exception as e:
            self.plugin.show_error(f"Failed to load {os.path.basename(file_path)}")
        return False

    def process_next_layer(self):
        """Process next pending layer"""
        if not self.pending_layers or self.current_layer:
            return

        file_path = self.pending_layers[0]
        self.current_layer = file_path
        
        try:
            layer = QgsPointCloudLayer(file_path, os.path.basename(file_path), "pdal")
            if layer and layer.isValid():
                QgsProject.instance().addMapLayer(layer)
                self.plugin.show_success(f"Loaded: {os.path.basename(file_path)}")
                self.pending_layers.pop(0)
                self.current_layer = None
                # Process next layer after delay
                QTimer.singleShot(10000, self.process_next_layer)
            else:
                self.plugin.show_error(f"Failed to load: {os.path.basename(file_path)}")
                self.pending_layers.pop(0)
                self.current_layer = None
                QTimer.singleShot(1000, self.process_next_layer)
        except Exception as e:
            self.plugin.show_error(f"Error loading layer: {str(e)}")
            self.pending_layers.pop(0)
            self.current_layer = None
            QTimer.singleShot(1000, self.process_next_layer)

    def process_next_file(self):
        """Process next file in queue with retries"""
        if not self.file_queue and self.failed_files:
            # Retry failed files after all others are done
            self.file_queue = self.failed_files
            self.failed_files = []
            self.plugin.show_message("Info", "Retrying failed files...", 0, 3)

        if not self.file_queue:
            self.loading = False
            self.verify_loaded_layers()
            return

        self.loading = True
        current_file = self.file_queue[0]
        retry_count = self.retry_counts.get(current_file, 0)

        try:
            layer = self.add_point_cloud_layer(current_file)
            if layer and layer.isValid() and self.verify_layer(layer):
                self.plugin.show_success(f"Loaded: {os.path.basename(current_file)}")
                self.file_queue.pop(0)
                self.retry_counts.pop(current_file, None)
                # Schedule next file after 10 seconds
                QTimer.singleShot(10000, self.process_next_file)
            else:
                self.handle_load_failure(current_file)
        except Exception as e:
            self.handle_load_failure(current_file)

    def handle_load_failure(self, file_path):
        """Handle failed load attempts"""
        retry_count = self.retry_counts.get(file_path, 0) + 1
        self.retry_counts[file_path] = retry_count
        
        if retry_count < self.max_retries:
            self.plugin.show_message("Warning", 
                f"Retry {retry_count}/{self.max_retries} for {os.path.basename(file_path)}", 1, 3)
            # Retry after 5 seconds
            QTimer.singleShot(5000, self.process_next_file)
        else:
            self.plugin.show_error(f"Temporarily skipping {os.path.basename(file_path)}")
            self.file_queue.pop(0)
            self.failed_files.append(file_path)
            # Continue with next file after 5 seconds
            QTimer.singleShot(5000, self.process_next_file)

    def verify_layer(self, layer):
        """Verify layer is properly loaded"""
        try:
            return (layer and 
                   layer.isValid() and 
                   layer.dataProvider() and 
                   layer.dataProvider().isValid() and
                   QgsProject.instance().mapLayer(layer.id()) is not None)
        except:
            return False

    def verify_loaded_layers(self):
        """Verify all layers are properly loaded"""
        project = QgsProject.instance()
        for layer_id in project.mapLayers():
            layer = project.mapLayer(layer_id)
            if isinstance(layer, QgsPointCloudLayer) and not self.verify_layer(layer):
                file_path = layer.source()
                if file_path not in self.failed_files:
                    self.failed_files.append(file_path)
                project.removeMapLayer(layer_id)
        
        if self.failed_files:
            self.plugin.show_message("Info", "Some layers need reloading...", 0, 3)
            QTimer.singleShot(5000, self.process_next_file)

    def add_point_cloud_layer(self, file_path):
        """Add LAS file as point cloud layer"""
        if not os.path.exists(file_path):
            return None

        base_name = os.path.basename(file_path)
        layer = QgsPointCloudLayer(file_path, base_name, "pdal")
        
        if layer.isValid():
            group = self._get_or_create_group(self._get_group_name(file_path))
            QgsProject.instance().addMapLayer(layer, False)
            group.addLayer(layer)
            self._configure_layer_renderer(layer)
            self.iface.mapCanvas().refresh()
            return layer
            
        return None

    def _delayed_add_layer(self, file_path):
        """Actually add the layer after delay"""
        try:
            layer = self.add_point_cloud_layer(file_path)
            if layer and layer.isValid():
                self.processed_files.add(file_path)
                self.plugin.show_success(f"Loaded: {os.path.basename(file_path)}")
                self.iface.mapCanvas().refresh()
        except Exception as e:
            self.plugin.show_error(f"Error loading delayed layer: {str(e)}")

    def _get_group_name(self, file_path):
        """Smart group name extraction from numbered sequence files"""
        base_name = os.path.basename(file_path)
        parent_dir = os.path.basename(os.path.dirname(file_path))
        
        # Extract sequence info (e.g., L1_1_UG_A_refl_001 -> UG_A)
        parts = base_name.split('_')
        if len(parts) >= 4:
            # Look for UG_A pattern
            for i in range(len(parts)-1):
                if parts[i].upper() == 'UG':
                    return f"{parts[i]}_{parts[i+1]}"
        
        return parent_dir

    def add_sequential_files(self, folder_path):
        """Add files with delay between each"""
        try:
            files = sorted([f for f in os.listdir(folder_path) 
                          if f.lower().endswith('.las')])
            self.pending_files.extend([os.path.join(folder_path, f) for f in files])
            if not self.is_loading:
                self.load_next_file()
        except Exception as e:
            self.plugin.show_error(f"Error scanning folder: {str(e)}")

    def load_next_file(self):
        """Load next file in queue after delay"""
        if not self.pending_files:
            self.is_loading = False
            return

        self.is_loading = True
        next_file = self.pending_files.pop(0)
        
        # Add current file
        if self.add_layer(next_file):
            self.plugin.show_message("Info", f"Loaded: {os.path.basename(next_file)}", 0, 2)
            
        # Schedule next file after 10 seconds
        QTimer.singleShot(10000, self.load_next_file)

    def _on_render_complete(self, file_path):
        """Handle layer render completion"""
        self.pending_renders -= 1
        if self.pending_renders == 0:
            # All layers finished rendering, wait 5 seconds then save
            self.plugin.show_success("All layers rendered successfully")
            QTimer.singleShot(5000, self.plugin.save_project)

    def _get_or_create_group(self, group_name):
        """Get or create layer group safely"""
        if group_name not in self.groups:
            group = self.root.findGroup(group_name)
            if not group:
                group = self.root.addGroup(group_name)
            self.groups[group_name] = group
        return self.groups[group_name]

    def _configure_layer_renderer(self, layer):
        """Configure layer renderer settings"""
        if renderer := layer.renderer():
            renderer.setPointSize(2)
            renderer.setMaximumScreenError(0.5)
        layer.triggerRepaint()

    def _handle_invalid_layer(self, file_path, retry_count):
        """Handle invalid layer loading"""
        if retry_count < 3:
            time.sleep(2)
            return self.add_point_cloud_layer(file_path, retry_count + 1)
        return None

    def _handle_layer_error(self, file_path, error, retry_count):
        """Handle layer loading errors with better feedback"""
        base_name = os.path.basename(file_path)
        if retry_count < 3:
            self.plugin.show_message("Info", f"Retrying {base_name} ({retry_count + 1}/3)...", 1, 2)
            time.sleep(2)
            return self.add_point_cloud_layer(file_path, None, retry_count + 1)
        self.plugin.show_error(f"Failed to load {base_name}: {str(error)}")
        return None

    def add_text_layer(self, file_path):
        """Add text/CSV file as vector layer"""
        try:
            base_name = os.path.basename(file_path)
            group_name = base_name.split('_')[0] if '_' in base_name else base_name.split('.')[0]
            
            uri = f"file:///{file_path}?delimiter=,&useHeader=yes&detectTypes=yes"
            layer = QgsVectorLayer(uri, base_name, "delimitedtext")
            
            if layer.isValid():
                group = self._get_or_create_group(group_name)
                QgsProject.instance().addMapLayer(layer, False)
                group.addLayer(layer)
                return layer
            
            self.plugin.show_error(f"Failed to load text file: {base_name}")
            return None
                
        except Exception as e:
            self.plugin.show_error(f"Error loading {os.path.basename(file_path)}: {str(e)}")
            return None

    def cleanup(self):
        """Cleanup resources"""
        self.processed_files.clear()
        self.rendered_files.clear()
        self.groups.clear()
        self.processed_paths.clear()
        self.layer_names.clear()
        self.loaded_sources.clear()
        self.loaded_files.clear()
        self.folder_groups.clear()

    def queue_layer(self, file_path):
        """Queue a file for loading"""
        if file_path not in self.pending_files:
            self.pending_files.append(file_path)
            if not self.is_loading:
                QTimer.singleShot(1000, self.load_next_layer)

    def load_next_layer(self):
        """Load next layer in queue"""
        if not self.pending_files:
            self.is_loading = False
            return

        self.is_loading = True
        file_path = self.pending_files.pop(0)
        try:
            layer = QgsPointCloudLayer(file_path, os.path.basename(file_path), "pdal")
            if layer and layer.isValid():
                QgsProject.instance().addMapLayer(layer)
                self.plugin.show_success(f"Added layer: {os.path.basename(file_path)}")
                # Schedule next layer after delay
                QTimer.singleShot(10000, self.load_next_layer)
            else:
                self.plugin.show_error(f"Failed to load: {os.path.basename(file_path)}")
                QTimer.singleShot(1000, self.load_next_layer)
        except Exception as e:
            self.plugin.show_error(f"Error: {str(e)}")
            QTimer.singleShot(1000, self.load_next_layer)

    def add_layer_to_group(self, file_path, group_name):
        """Add a layer to a specific group, avoiding duplicates"""
        # Skip if already loaded
        if self.is_duplicate(file_path):
            return True
            
        try:
            file_name = os.path.basename(file_path)
            layer = QgsPointCloudLayer(file_path, file_name, "pdal")
            
            if layer and layer.isValid():
                # Get or create the group if it doesn't exist
                root = QgsProject.instance().layerTreeRoot()
                group = root.findGroup(group_name)
                if not group:
                    group = root.addGroup(group_name)
                
                # Add layer to project without adding to legend
                QgsProject.instance().addMapLayer(layer, False)
                # Add layer to specific group
                group.addLayer(layer)
                
                # Track loaded path in multiple ways for redundant checking
                self.loaded_paths.add(os.path.normpath(file_path))
                self.loaded_sources.add(os.path.normpath(file_path))
                
                self.plugin.show_success(f"Added {file_name} to group {group_name}")
                return True
        except Exception as e:
            self.plugin.show_error(f"Failed to add {os.path.basename(file_path)}: {str(e)}")
        
        return False
